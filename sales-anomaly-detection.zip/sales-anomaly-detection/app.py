import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st


# Allow Python to import src/anomaly_detector.py
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.append(str(PROJECT_ROOT))

from src.anomaly_detector import detect_anomalies


st.set_page_config(
    page_title="Sales Anomaly Detection",
    page_icon="🚨",
    layout="wide",
)


st.title("🚨 AI-Powered Sales Anomaly Detection System")

st.caption(
    "Detect unusual sales, losses, discounts and transaction patterns "
    "using business rules, statistics and Isolation Forest."
)


# -------------------------
# SIDEBAR
# -------------------------

st.sidebar.header("Detection Settings")

contamination = st.sidebar.slider(
    "Expected anomaly percentage",
    min_value=0.01,
    max_value=0.10,
    value=0.03,
    step=0.01,
)

risk_threshold = st.sidebar.slider(
    "Minimum risk score",
    min_value=0,
    max_value=100,
    value=30,
    step=5,
)


# -------------------------
# FILE UPLOAD
# -------------------------

uploaded_file = st.file_uploader(
    "Upload Sales CSV",
    type=["csv"],
)


if uploaded_file is None:
    st.info(
        "Upload the retail-sales CSV to begin anomaly detection."
    )

    st.stop()


# -------------------------
# LOAD DATA
# -------------------------

try:
    raw_df = pd.read_csv(uploaded_file)
except Exception as e:
    st.error(f"Could not read CSV: {e}")
    st.stop()


required_columns = {
    "Order_ID",
    "Order_Date",
    "Sales",
    "Quantity",
    "Discount",
    "Profit",
}

missing_columns = required_columns - set(raw_df.columns)

if missing_columns:
    st.error(
        "The uploaded file is missing these required columns: "
        + ", ".join(sorted(missing_columns))
    )
    st.stop()


# -------------------------
# DATASET PREVIEW
# -------------------------

with st.expander("View Raw Dataset", expanded=False):

    st.write(
        f"Raw rows: **{len(raw_df):,}** | "
        f"Columns: **{len(raw_df.columns)}**"
    )

    st.dataframe(
        raw_df.head(25),
        use_container_width=True,
    )


# -------------------------
# RUN MODEL
# -------------------------

with st.spinner("Cleaning data and detecting anomalies..."):

    results, model = detect_anomalies(
        raw_df,
        contamination=contamination,
    )


anomalies = results[
    results["Risk_Score"] >= risk_threshold
].copy()


# -------------------------
# KPI DASHBOARD
# -------------------------

st.subheader("Executive Overview")

total_transactions = len(results)
total_anomalies = len(anomalies)

critical_count = (
    results["Severity"] == "Critical"
).sum()

high_count = (
    results["Severity"] == "High"
).sum()

anomaly_rate = (
    total_anomalies / total_transactions * 100
    if total_transactions
    else 0
)

total_sales = results["Sales"].sum()
total_profit = results["Profit"].sum()


col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Transactions",
    f"{total_transactions:,}",
)

col2.metric(
    "Detected Anomalies",
    f"{total_anomalies:,}",
)

col3.metric(
    "Anomaly Rate",
    f"{anomaly_rate:.2f}%",
)

col4.metric(
    "Critical Cases",
    f"{critical_count:,}",
)


col5, col6, col7, col8 = st.columns(4)

col5.metric(
    "Total Sales",
    f"₹{total_sales:,.0f}",
)

col6.metric(
    "Total Profit",
    f"₹{total_profit:,.0f}",
)

col7.metric(
    "High Risk Cases",
    f"{high_count:,}",
)

col8.metric(
    "Highest Risk Score",
    int(results["Risk_Score"].max()),
)


st.divider()


# -------------------------
# TABS
# -------------------------

tab1, tab2, tab3, tab4, tab5 = st.tabs(
    [
        "📊 Dashboard",
        "🚨 Anomalies",
        "📈 Model Insights",
        "✅ Evaluation",
        "📥 Export",
    ]
)


# ========================================================
# TAB 1 - DASHBOARD
# ========================================================

with tab1:

    st.subheader("Anomaly Severity")

    severity_counts = (
        results["Severity"]
        .value_counts()
        .reset_index()
    )

    severity_counts.columns = [
        "Severity",
        "Count",
    ]

    severity_fig = px.bar(
        severity_counts,
        x="Severity",
        y="Count",
        title="Transactions by Risk Severity",
    )

    st.plotly_chart(
        severity_fig,
        use_container_width=True,
    )


    col1, col2 = st.columns(2)

    with col1:

        scatter_fig = px.scatter(
            results,
            x="Sales",
            y="Profit",
            color="Severity",
            hover_data=[
                "Order_ID",
                "Quantity",
                "Discount",
                "Risk_Score",
                "Anomaly_Reason",
            ],
            title="Sales vs Profit",
        )

        st.plotly_chart(
            scatter_fig,
            use_container_width=True,
        )


    with col2:

        risk_fig = px.histogram(
            results,
            x="Risk_Score",
            nbins=20,
            title="Risk Score Distribution",
        )

        st.plotly_chart(
            risk_fig,
            use_container_width=True,
        )


    if "Region" in results.columns:

        region_summary = (
            anomalies.groupby("Region")
            .size()
            .reset_index(name="Anomalies")
            .sort_values(
                "Anomalies",
                ascending=False,
            )
        )

        region_fig = px.bar(
            region_summary,
            x="Region",
            y="Anomalies",
            title="Anomalies by Region",
        )

        st.plotly_chart(
            region_fig,
            use_container_width=True,
        )


# ========================================================
# TAB 2 - ANOMALY TABLE
# ========================================================

with tab2:

    st.subheader("Detected Anomalies")

    severity_filter = st.multiselect(
        "Filter by severity",
        options=[
            "Critical",
            "High",
            "Medium",
            "Low",
        ],
        default=[
            "Critical",
            "High",
            "Medium",
        ],
    )

    filtered = anomalies[
        anomalies["Severity"].isin(
            severity_filter
        )
    ].copy()

    if "Region" in filtered.columns:

        regions = sorted(
            filtered["Region"]
            .dropna()
            .unique()
            .tolist()
        )

        selected_regions = st.multiselect(
            "Filter by region",
            options=regions,
            default=regions,
        )

        filtered = filtered[
            filtered["Region"].isin(
                selected_regions
            )
        ]


    display_columns = [
        "Order_ID",
        "Order_Date",
        "Region",
        "Category",
        "Sales",
        "Quantity",
        "Discount",
        "Profit",
        "Risk_Score",
        "Severity",
        "Anomaly_Score",
        "Anomaly_Reason",
        "Recommended_Action",
    ]

    display_columns = [
        col
        for col in display_columns
        if col in filtered.columns
    ]

    st.write(
        f"Showing **{len(filtered):,}** suspicious transactions."
    )

    st.dataframe(
        filtered[display_columns]
        .sort_values(
            "Risk_Score",
            ascending=False,
        ),
        use_container_width=True,
        height=500,
    )


# ========================================================
# TAB 3 - MODEL INSIGHTS
# ========================================================

with tab3:

    st.subheader("How anomalies were detected")

    method_counts = pd.DataFrame(
        {
            "Method": [
                "Business Rules",
                "IQR",
                "Z-Score",
                "Isolation Forest",
            ],
            "Detected": [
                (
                    results[
                        "Business_Rule_Score"
                    ] > 0
                ).sum(),

                results[
                    "Sales_IQR_Anomaly"
                ].sum(),

                results[
                    "ZScore_Anomaly"
                ].sum(),

                results[
                    "ML_Anomaly"
                ].sum(),
            ],
        }
    )

    detection_fig = px.bar(
        method_counts,
        x="Method",
        y="Detected",
        title="Detection Methods Comparison",
    )

    st.plotly_chart(
        detection_fig,
        use_container_width=True,
    )


    st.markdown(
        """
        **Business Rules:** identify obvious business risks such as
        extreme discounts, large losses and unusual quantities.

        **IQR:** detects values outside the normal statistical sales range.

        **Z-Score:** identifies sales far from the overall mean.

        **Isolation Forest:** detects unusual multi-variable transaction
        patterns using unsupervised machine learning.

        **Risk Score:** combines all detection signals into a business-friendly
        score from 0 to 100.
        """
    )


# ========================================================
# TAB 4 - EVALUATION
# ========================================================

with tab4:

    st.subheader("Model Evaluation")

    if "Ground_Truth_Anomaly" in results.columns:

        actual = pd.to_numeric(
            results["Ground_Truth_Anomaly"],
            errors="coerce",
        ).fillna(0).astype(int)

        predicted = (
            results["Risk_Score"]
            >= risk_threshold
        ).astype(int)

        tp = (
            (actual == 1)
            & (predicted == 1)
        ).sum()

        fp = (
            (actual == 0)
            & (predicted == 1)
        ).sum()

        fn = (
            (actual == 1)
            & (predicted == 0)
        ).sum()

        tn = (
            (actual == 0)
            & (predicted == 0)
        ).sum()

        precision = (
            tp / (tp + fp)
            if tp + fp
            else 0
        )

        recall = (
            tp / (tp + fn)
            if tp + fn
            else 0
        )

        f1 = (
            2 * precision * recall
            / (precision + recall)
            if precision + recall
            else 0
        )


        c1, c2, c3 = st.columns(3)

        c1.metric(
            "Precision",
            f"{precision:.2%}",
        )

        c2.metric(
            "Recall",
            f"{recall:.2%}",
        )

        c3.metric(
            "F1 Score",
            f"{f1:.2%}",
        )


        confusion = pd.DataFrame(
            {
                "Metric": [
                    "True Positive",
                    "False Positive",
                    "False Negative",
                    "True Negative",
                ],
                "Count": [
                    tp,
                    fp,
                    fn,
                    tn,
                ],
            }
        )

        st.dataframe(
            confusion,
            use_container_width=True,
        )


        if "Anomaly_Type" in results.columns:

            detected_types = (
                results[
                    (
                        results[
                            "Ground_Truth_Anomaly"
                        ] == 1
                    )
                ]
                .groupby("Anomaly_Type")
                .agg(
                    Actual=("Order_ID", "count"),
                    Detected=(
                        "Risk_Score",
                        lambda x: (
                            x >= risk_threshold
                        ).sum(),
                    ),
                )
                .reset_index()
            )

            detected_types[
                "Detection_Rate"
            ] = (
                detected_types["Detected"]
                / detected_types["Actual"]
                * 100
            )

            st.subheader(
                "Detection by Injected Anomaly Type"
            )

            st.dataframe(
                detected_types,
                use_container_width=True,
            )

    else:

        st.info(
            "Ground truth labels are not present in this uploaded dataset, "
            "so supervised evaluation is unavailable."
        )


# ========================================================
# TAB 5 - EXPORT
# ========================================================

with tab5:

    st.subheader("Export Results")

    result_csv = results.to_csv(
        index=False
    ).encode("utf-8")

    anomaly_csv = anomalies.to_csv(
        index=False
    ).encode("utf-8")


    st.download_button(
        "Download Full Analysed Dataset",
        data=result_csv,
        file_name="analysed_sales_data.csv",
        mime="text/csv",
    )

    st.download_button(
        "Download Detected Anomalies",
        data=anomaly_csv,
        file_name="detected_anomalies.csv",
        mime="text/csv",
    )