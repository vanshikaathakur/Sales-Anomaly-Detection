import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest


def _clean_numeric(series, is_discount=False):
    """
    Converts messy numeric values such as:
    ₹12,500.00
    12500 INR
    12500rs
    50%
    into numeric values.
    """

    s = series.astype(str).str.strip()

    percent_mask = s.str.contains("%", regex=False)

    s = (
        s.str.replace("₹", "", regex=False)
        .str.replace(",", "", regex=False)
        .str.replace("INR", "", regex=False)
        .str.replace("rs", "", case=False, regex=False)
        .str.replace("%", "", regex=False)
        .str.strip()
    )

    numeric = pd.to_numeric(s, errors="coerce")

    if is_discount:
        numeric.loc[percent_mask] = numeric.loc[percent_mask] / 100

    return numeric


def clean_data(df):
    df = df.copy()

    # Clean column names
    df.columns = df.columns.str.strip()

    # Remove exact duplicates
    df = df.drop_duplicates().copy()

    # Clean text columns
    text_columns = [
        "Region",
        "Category",
        "Sub_Category",
        "Customer_Segment",
        "Payment_Mode",
    ]

    for col in text_columns:
        if col in df.columns:
            df[col] = df[col].astype("string").str.strip()

    # Standardize region
    if "Region" in df.columns:
        region_map = {
            "N": "North",
            "NORTH": "North",
            "north": "North",
            "S": "South",
            "SOUTH": "South",
            "south": "South",
            "E": "East",
            "EAST": "East",
            "east": "East",
            "W": "West",
            "WEST": "West",
            "west": "West",
            "C": "Central",
            "CENTRAL": "Central",
            "central": "Central",
        }

        df["Region"] = df["Region"].replace(region_map)

    # Standardize category
    if "Category" in df.columns:
        category_map = {
            "TECHNOLOGY": "Technology",
            "technology": "Technology",
            "Tech": "Technology",
            "FURNITURE": "Furniture",
            "furniture": "Furniture",
            "Furn.": "Furniture",
            "OFFICE SUPPLIES": "Office Supplies",
            "office supplies": "Office Supplies",
            "Office-Supplies": "Office Supplies",
        }

        df["Category"] = df["Category"].replace(category_map)

    # Parse dates
    if "Order_Date" in df.columns:
        df["Order_Date"] = pd.to_datetime(
            df["Order_Date"],
            format="mixed",
            errors="coerce",
        )

    # Clean numeric columns
    if "Sales" in df.columns:
        df["Sales"] = _clean_numeric(df["Sales"])

    if "Quantity" in df.columns:
        df["Quantity"] = _clean_numeric(df["Quantity"])

    if "Profit" in df.columns:
        df["Profit"] = _clean_numeric(df["Profit"])

    if "Discount" in df.columns:
        df["Discount"] = _clean_numeric(
            df["Discount"],
            is_discount=True,
        )

    # Only remove rows that cannot be analysed
    df = df.dropna(
        subset=["Sales", "Profit", "Quantity"]
    ).copy()

    # Fill missing discounts
    df["Discount"] = df["Discount"].fillna(0)

    return df


def add_features(df):
    df = df.copy()

    df["Profit_Margin"] = np.where(
        df["Sales"] != 0,
        df["Profit"] / df["Sales"],
        0,
    )

    df["Sales_Per_Unit"] = np.where(
        df["Quantity"] != 0,
        df["Sales"] / df["Quantity"],
        np.nan,
    )

    df["Loss_Flag"] = (df["Profit"] < 0).astype(int)

    return df


def add_business_rules(df):
    df = df.copy()

    df["High_Discount_Flag"] = (
        df["Discount"] > 0.50
    ).astype(int)

    df["Large_Loss_Flag"] = (
        df["Profit"] < -5000
    ).astype(int)

    df["High_Quantity_Flag"] = (
        df["Quantity"] > 10
    ).astype(int)

    df["Low_Margin_Flag"] = (
        df["Profit_Margin"] < -0.25
    ).astype(int)

    df["Business_Rule_Score"] = (
        df["High_Discount_Flag"]
        + df["Large_Loss_Flag"]
        + df["High_Quantity_Flag"]
        + df["Low_Margin_Flag"]
    )

    return df


def add_statistical_anomalies(df):
    df = df.copy()

    # IQR
    q1 = df["Sales"].quantile(0.25)
    q3 = df["Sales"].quantile(0.75)

    iqr = q3 - q1

    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr

    df["Sales_IQR_Anomaly"] = (
        (df["Sales"] < lower_bound)
        | (df["Sales"] > upper_bound)
    ).astype(int)

    # Z-score
    mean_sales = df["Sales"].mean()
    std_sales = df["Sales"].std()

    if std_sales == 0 or pd.isna(std_sales):
        df["Sales_ZScore"] = 0
    else:
        df["Sales_ZScore"] = (
            df["Sales"] - mean_sales
        ) / std_sales

    df["ZScore_Anomaly"] = (
        df["Sales_ZScore"].abs() > 3
    ).astype(int)

    return df


def add_isolation_forest(df, contamination=0.03):
    df = df.copy()

    features = [
        "Sales",
        "Quantity",
        "Discount",
        "Profit",
        "Profit_Margin",
    ]

    X = (
        df[features]
        .replace([np.inf, -np.inf], np.nan)
        .fillna(0)
    )

    model = IsolationForest(
        n_estimators=200,
        contamination=contamination,
        random_state=42,
    )

    df["Isolation_Forest_Result"] = model.fit_predict(X)

    df["ML_Anomaly"] = (
        df["Isolation_Forest_Result"] == -1
    ).astype(int)

    # Larger number = more suspicious for our dashboard
    df["Anomaly_Score"] = -model.decision_function(X)

    return df, model


def assign_severity(score):
    if score >= 70:
        return "Critical"
    elif score >= 50:
        return "High"
    elif score >= 30:
        return "Medium"
    return "Low"


def generate_reason(row):
    reasons = []

    if row["High_Discount_Flag"] == 1:
        reasons.append("Unusually high discount")

    if row["Large_Loss_Flag"] == 1:
        reasons.append("Large financial loss")

    if row["High_Quantity_Flag"] == 1:
        reasons.append("Unusually high order quantity")

    if row["Low_Margin_Flag"] == 1:
        reasons.append("Abnormally low profit margin")

    if row["Sales_IQR_Anomaly"] == 1:
        reasons.append("Sales outside normal IQR range")

    if row["ZScore_Anomaly"] == 1:
        reasons.append("Extreme sales Z-score")

    if row["ML_Anomaly"] == 1:
        reasons.append("Isolation Forest detected unusual pattern")

    return ", ".join(reasons) if reasons else "No major anomaly detected"


def recommended_action(row):
    if row["Severity"] == "Critical":
        return "Investigate immediately"

    if row["High_Discount_Flag"] == 1:
        return "Review discount approval"

    if row["Large_Loss_Flag"] == 1:
        return "Investigate profitability"

    if row["High_Quantity_Flag"] == 1:
        return "Verify order quantity"

    if row["ML_Anomaly"] == 1:
        return "Review unusual transaction pattern"

    return "Monitor"


def detect_anomalies(df, contamination=0.03):
    df = clean_data(df)

    df = add_features(df)

    df = add_business_rules(df)

    df = add_statistical_anomalies(df)

    df, model = add_isolation_forest(
        df,
        contamination=contamination,
    )

    df["Risk_Score"] = (
        df["Business_Rule_Score"] * 15
        + df["Sales_IQR_Anomaly"] * 10
        + df["ZScore_Anomaly"] * 10
        + df["ML_Anomaly"] * 30
    ).clip(upper=100)

    df["Severity"] = df["Risk_Score"].apply(
        assign_severity
    )

    df["Anomaly_Reason"] = df.apply(
        generate_reason,
        axis=1,
    )

    df["Recommended_Action"] = df.apply(
        recommended_action,
        axis=1,
    )

    return df, model